<?php
    error_reporting(0);

    $conexion = mysqli_connect("localhost","312306","eeerrr96","312306");

    if(!$conexion)
    {
        exit("Error al intentar conectarse al servidor MYSQL.");
    }

    
    $cedula= $_POST['cedula'];
    $idCurso= $_POST['idCurso'];
    $fecha = date('Y', time());

    if(empty($cedula) or empty($idCurso) ){
        exit("ERROR: debe llenar todos los espacios.");
    }

    $query = "INSERT INTO CursosEstudiantes (periodo,idCurso,cedula) VALUES ('$fecha','$idCurso','$cedula')";

    if(mysqli_query($conexion, $query)){
        echo "Added successfully.";
    } else{
        echo "ERROR: Could not able to execute $query. " . mysqli_error($conexion);
    }
     
    // Close connection
    mysqli_close($conexion);
    
    
?>