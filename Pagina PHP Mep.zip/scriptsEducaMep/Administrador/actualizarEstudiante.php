<?php
    error_reporting(0);

    $conexion = mysqli_connect("localhost","312306","eeerrr96","312306");

    if(!$conexion)
    {
        exit("Error al intentar conectarse al servidor MYSQL.");
    }

    $cedula= $_POST['cedula'];
    $nombre= $_POST['nombre'];
    $apellido1= $_POST['apellido1'];
    $apellido2= $_POST['apellido2'];
    $correo= $_POST['correo'];

    if(empty($cedula) or empty($nombre) or empty($apellido1) or empty($apellido2) or empty($correo)){
        exit("ERROR: debe llenar todos los espacios.");
    }

    $query = "UPDATE Estudiante SET nombre='$nombre',apellido1='$apellido1',apellido2='$apellido2',correo='$correo' WHERE cedula='$cedula' ";

    if(mysqli_query($conexion, $query)){
        echo "Updated successfully.";
    } else{
        echo "ERROR: Could not able to execute $query. " . mysqli_error($conexion);
    }
     
    // Close connection
    mysqli_close($conexion);
    
    
?>