<?php

    error_reporting(0);

    $conexion = mysqli_connect("localhost","312306","eeerrr96","312306");

    if(!$conexion)
    {
        exit("Error al intentar conectarse al servidor MYSQL.");
    }


    $query = "SELECT cedula,nombre,apellido1,apellido2,correo FROM Docente";

    // Ejecutar la consulta
    $resultado = mysqli_query($conexion, $query);


    // Usar el resultado
    // Si se intenta imprimir $resultado no será posible acceder a la información del recurso
    // Se debe usar una de las funciones de resultados de mysql
    // Consulte también mysql_result(), mysql_fetch_array(), mysql_fetch_row(), etc.
    while($consulta = mysqli_fetch_array($resultado)){
        echo "{$consulta['cedula']};{$consulta['nombre']};{$consulta['apellido1']};{$consulta['apellido2']};{$consulta['correo']}#";
    }
    mysqli_close($conexion);
?>