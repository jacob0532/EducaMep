<?php
    error_reporting(0);

    $conexion = mysqli_connect("localhost","312306","eeerrr96","312306");

    if(!$conexion)
    {
        exit("Error al intentar conectarse al servidor MYSQL.");
    }

    $cedula= $_POST['cedula'];

    if(empty($cedula) ){
        exit("ERROR: debe llenar todos los espacios.");
    }

    $query = "DELETE FROM Docente WHERE cedula='$cedula'";

    if(mysqli_query($conexion, $query)){
        echo "Deleted successfully.";
    } else{
        echo "ERROR: Could not able to execute $query. " . mysqli_error($conexion);
    }
     
    // Close connection
    mysqli_close($conexion);
    
    
?>