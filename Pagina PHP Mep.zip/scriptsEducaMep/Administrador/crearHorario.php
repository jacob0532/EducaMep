<?php
    error_reporting(0);

    $conexion = mysqli_connect("localhost","312306","eeerrr96","312306");

    if(!$conexion)
    {
        exit("Error al intentar conectarse al servidor MYSQL.");
    }

    $resultadoVar = mysqli_query($conexion, "SELECT max(idCurso) FROM Curso");
    $fila = mysqli_fetch_row($resultadoVar);
    $idCurso= $fila[0];
    $dia= $_POST['dia'];
    $horaInicio= $_POST['horaInicio'];
    $horaFinal= $_POST['horaFinal'];


    if( empty($idCurso) or empty($dia) or empty($horaInicio) or empty($horaFinal) ){
        exit("ERROR: debe llenar todos los espacios.");
    }

    $query = "INSERT INTO Horario (idCurso,horaInicio,horaFinal,dia) VALUES ('$idCurso','$horaInicio','$horaFinal','$dia')";

    if(mysqli_query($conexion, $query)){
        echo "Added successfully.";
    } else{
        echo "ERROR: Could not able to execute $query. " . mysqli_error($conexion);
    }
     
    // Close connection
    mysqli_close($conexion);
    
    
?>			