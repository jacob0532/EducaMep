<?php
    $conexion = mysqli_connect("localhost","312306","eeerrr96","312306");

    $idCurso= $_GET['idCurso'];

    if(empty($idCurso) ){
        exit("ERROR: debe llenar todos los espacios.");
    }

    $query = "DELETE FROM Curso WHERE idCurso='$idCurso'";

    if(mysqli_query($conexion, $query)){
        echo "Deleted successfully.";
    } else{
        echo "ERROR: Could not able to execute $query. " . mysqli_error($conexion);
    }
     
    // Close connection
    mysqli_close($conexion);
    
    
?>