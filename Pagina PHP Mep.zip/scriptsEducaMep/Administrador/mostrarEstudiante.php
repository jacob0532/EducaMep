<?php
    error_reporting(0);

    $conexion = mysqli_connect("localhost","312306","eeerrr96","312306");

    if(!$conexion)
    {
        exit("Error al intentar conectarse al servidor MYSQL.");
    }

    $query = "SELECT cedula,nombre,apellido1,apellido2,correo FROM Estudiante";

    // Ejecutar la consulta
    $resultado = mysqli_query($conexion, $query);
    mysqli_close($conexion);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Gesti�n de estudiantes</title>

</head>
<body>
    <h1 align="center">LISTADO DE ESTUDIANTES</h1>
    <table width="70%" border="1px" align="center">

    <tr align="center">
        <td>Cedula</td>
        <td>Nombre</td>
        <td>Apellido1</td>
        <td>Apellido2</td>
        <td>Correo</td>
        <td>Modificar Estudiante</td>
        <td>Eliminar Estudiante</td>
    </tr>
    <?php 
        while($datos=$resultado->fetch_array()){
        ?>
            <tr align="center">
                <td><?=$datos["cedula"]?></td>
                <td><?=$datos["nombre"]?></td>
                <td><?=$datos["apellido1"]?></td>
                <td><?=$datos["apellido2"]?></td>
                <td><?=$datos["correo"]?></td>
                <td> <a href="actualizarEstudiante.php?id='.$cedula.'"><button  value="Editar"/>Editar</button></a> </td> 
                <td><button>Eliminar</button></td>
            </tr>
            <?php   
        }

     ?>
    </table>

</body>
</html>