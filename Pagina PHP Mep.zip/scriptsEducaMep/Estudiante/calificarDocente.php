
<?php
    error_reporting(0);

    $conexion = mysqli_connect("localhost","312306","eeerrr96","312306");

    if(!$conexion)
    {
        exit("Error al intentar conectarse al servidor MYSQL.");
    }

    $calificacion= $_POST['calificacion'];
    $idCurso= $_POST['idCurso'];
    $docente= $_POST['docente'];//Cedula del docente
    $estudiante= $_POST['estudiante'];;//Cedula del estudiante

    if(empty($idCurso) or empty($docente) or empty($estudiante) or empty($calificacion) ){
        exit("ERROR: debe llenar todos los espacios.");
    }

    if($calificacion<1 or $calificacion>5)
    {
        exit("ERROR: la calificación debe ser de 1 a 5.");
    }
  

    $query = "INSERT INTO Calificacion (calificacion,estudiante,docente,idCurso) VALUES ('$calificacion','$estudiante',$docente,'$idCurso')";

    if(mysqli_query($conexion, $query)){
        echo "Added successfully.";
    } else{
        echo "ERROR: Could not able to execute $query. " . mysqli_error($conexion);
    }
     
    // Close connection
    mysqli_close($conexion);
    
    
?>