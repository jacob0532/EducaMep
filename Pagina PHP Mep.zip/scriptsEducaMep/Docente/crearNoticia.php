<?php
    error_reporting(0);

    $conexion = mysqli_connect("localhost","312306","eeerrr96","312306");

    if(!$conexion)
    {
        exit("Error al intentar conectarse al servidor MYSQL.");
    }

    $titulo= $_POST['titulo'];
    $idCurso= $_POST['idCurso'];
    $texto= $_POST['texto'];
    $fecha = date('Y-m-d', time());

    if(empty($idCurso) or empty($titulo) or empty($texto) ){
        exit("ERROR: debe llenar todos los espacios.");
    }
  

    $query = "INSERT INTO Noticia (titulo,idCurso,texto,fecha) VALUES ('$titulo','$idCurso','$texto','$fecha')";

    if(mysqli_query($conexion, $query)){
        echo "Added successfully.";
    } else{
        echo "ERROR: Could not able to execute $query. " . mysqli_error($conexion);
    }
     
    // Close connection
    mysqli_close($conexion);
    
    
?>