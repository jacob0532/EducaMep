<?php
    error_reporting(0);

    $conexion = mysqli_connect("localhost","312306","eeerrr96","312306");

    if(!$conexion)
    {
        exit("Error al intentar conectarse al servidor MYSQL.");
    }

    $titulo= $_POST['titulo'];
    $idCurso= $_POST['idCurso'];
    $descripcion= $_POST['descripcion'];
    $fechaEntrega= $_POST['fechaEntrega'];
    $fechaAsignacion = date('Y-m-d', time());

    if(empty($idCurso) or empty($titulo) or empty($descripcion) or empty($fechaEntrega) ){
        exit("ERROR: debe llenar todos los espacios.");
    }
  

    $query = "INSERT INTO Tarea (titulo,idCurso,fechaEntrega,fechaAsignacion) VALUES ('$titulo','$idCurso','$descripcion', '$fechaEntrega','$fechaAsignacion')";

    if(mysqli_query($conexion, $query)){
        echo "Added successfully.";
    } else{
        echo "ERROR: Could not able to execute $query. " . mysqli_error($conexion);
    }
     
    // Close connection
    mysqli_close($conexion);
    
    
?>